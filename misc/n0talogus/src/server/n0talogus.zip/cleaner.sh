#!/bin/bash
set -o history

history -c && history -w
